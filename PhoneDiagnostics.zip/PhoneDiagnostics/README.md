# Phone Diagnostics (Android APK)

A dependency-free Kotlin app with a colourful, animated 4-tab UI (Home, Speed, Compare, Details), built with custom Canvas views: speed gauge, line charts, bar charts, progress rings and animated meters. It shows, live on your phone:

- **Device**: model, Android version, CPU, ABIs, security patch, uptime, IDs
- **Battery**: level, health, temperature, voltage, current, charging state
- **Display, memory, storage, camera list, hardware features**
- **Signals**: mobile (dBm per cell/RAT, operator, SIM, network type), Wi-Fi (RSSI, speed, scan results), internet validation, Bluetooth, NFC
- **GPS**: fix, accuracy, speed, satellites visible/used
- **All sensors**: every sensor on the phone is registered and checked; shows LIVE / WAITING / one-shot, with live values
- **Screen time**: today + last 7 days, top apps, screen-on & unlock counts (needs Usage Access)
- **Internet speed test**: ping, jitter, download, upload (Cloudflare endpoints)
- **History + comparison**: every test is saved with time, location, network and signal; compare **by time of day, by day, by location**, and *this location vs overall*, with a Wi-Fi/Mobile filter and CSV export
- **Quick health check** ✓/✗ summary and a **Copy report** button

## Get the APK (no Android Studio needed)
1. Create a GitHub repo and push this folder.
2. Open **Actions → Build APK → Run workflow** (it also runs on every push).
3. Download the `PhoneDiagnostics-apk` artifact → install `app-debug.apk` (allow "install unknown apps").
4. Tag `v1.0` (`git tag v1.0 && git push --tags`) to publish APKs as a GitHub Release.

## Build locally
Open in Android Studio, or run `gradle assembleDebug` (Gradle 8.9+, JDK 17, Android SDK 34).

## Permissions
Tap **Permissions** to grant runtime permissions. For screen time tap **Usage Access** and enable *Phone Diagnostics*.
History is stored only on the device (SQLite). The only network traffic is the speed test to `speed.cloudflare.com` (edit `SpeedTest.kt` to use your own server). A test can use 100+ MB.

package com.example.phonediag

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.bluetooth.BluetoothManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.TriggerEvent
import android.hardware.TriggerEventListener
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.location.Geocoder
import android.location.GnssStatus
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.nfc.NfcAdapter
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.StatFs
import android.os.SystemClock
import android.provider.Settings
import android.telephony.CellInfo
import android.telephony.CellInfoGsm
import android.telephony.CellInfoLte
import android.telephony.CellInfoNr
import android.telephony.CellInfoWcdma
import android.telephony.TelephonyManager
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.view.View
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import kotlin.math.roundToInt
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

@SuppressLint("MissingPermission", "HardwareIds")
@Suppress("DEPRECATION")
class MainActivity : Activity(), SensorEventListener, LocationListener {

    private lateinit var tv: TextView
    private lateinit var db: HistoryDb
    private lateinit var btnFilter: Button
    private val filters = listOf("All", "Wi-Fi", "Mobile")
    private var filterIdx = 0
    @Volatile private var testing = false
    @Volatile private var speedStatus = ""
    @Volatile private var lastSpeed: SpeedResult? = null
    @Volatile private var histCache: String? = null
    @Volatile private var histTime = 0L
    private lateinit var sm: SensorManager
    private val handler = Handler(Looper.getMainLooper())

    private val values = HashMap<Sensor, FloatArray>()
    private val counts = HashMap<Sensor, Int>()
    private val regState = HashMap<Sensor, String>()
    private var loc: Location? = null
    private var locTime = 0L
    private var sats = 0
    private var satsUsed = 0
    private var gnssRegistered = false

    private val ticker = object : Runnable {
        override fun run() {
            refreshUi()
            handler.postDelayed(this, if (testing) 300L else 1500L)
        }
    }

    private val trigger = object : TriggerEventListener() {
        override fun onTrigger(e: TriggerEvent) {
            counts[e.sensor] = (counts[e.sensor] ?: 0) + 1
            values[e.sensor] = e.values.clone()
        }
    }

    private val gnss = object : GnssStatus.Callback() {
        override fun onSatelliteStatusChanged(status: GnssStatus) {
            sats = status.satelliteCount
            satsUsed = (0 until status.satelliteCount).count { status.usedInFix(it) }
        }
    }

    // ───────────────────────── UI ─────────────────────────
    private val ctx: Context get() = this
    private val updaters = ArrayList<() -> Unit>()
    private val pages = ArrayList<LinearLayout>()
    private val pageScrolls = ArrayList<ScrollView>()
    private val tabLabels = ArrayList<TextView>()
    private var curTab = 0
    private lateinit var content: FrameLayout
    @Volatile private var rowsCache: List<Reading>? = null
    private var rowsTime = 0L
    private var usageCache: List<Pair<String, Long>> = emptyList()
    private var usageTotal = 0L
    private var usageTime = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sm = getSystemService(SENSOR_SERVICE) as SensorManager
        db = HistoryDb(this)
        window.statusBarColor = C.INDIGO

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(C.BG) }
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(C.CARD)
            elevation = dpf(10f)
            setPadding(0, dp(6), 0, dp(6))
        }
        listOf("◉\nHome", "⚡\nSpeed", "▥\nCompare", "☰\nDetails").forEachIndexed { i, n ->
            val t = txt(this, n, 12f, C.MUTED, true)
            t.gravity = Gravity.CENTER
            t.setOnClickListener { showTab(i) }
            tabLabels.add(t)
            bar.addView(t, lp(0, -2, 1f))
        }
        root.addView(bar, lp(-1, -2))
        setContentView(root)

        buildHome(); buildSpeed(); buildCompare(); buildDetails()
        showTab(0)
        if (missingPerms().isNotEmpty()) requestAll()
    }

    private fun newPage(): LinearLayout {
        val sv = ScrollView(this)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(24)) }
        sv.addView(l)
        sv.visibility = View.GONE
        content.addView(sv, FrameLayout.LayoutParams(-1, -1))
        pageScrolls.add(sv); pages.add(l)
        return l
    }

    private fun showTab(i: Int) {
        curTab = i
        pageScrolls.forEachIndexed { k, sv -> sv.visibility = if (k == i) View.VISIBLE else View.GONE }
        tabLabels.forEachIndexed { k, t ->
            t.setTextColor(if (k == i) C.INDIGO else C.MUTED)
            val s = if (k == i) 1.12f else 1f
            t.animate().scaleX(s).scaleY(s).setDuration(200).start()
        }
        val page = pages[i]
        for (c in 0 until page.childCount) page.getChildAt(c).popIn(c * 70L)
        refreshUi()
    }

    private fun onTick(f: () -> Unit) { updaters.add(f) }

    private fun refreshUi() {
        updaters.forEach { try { it() } catch (_: Exception) {} }
        if (curTab == 3) tv.text = buildReport()
    }

    private fun refill(box: LinearLayout, key: String, build: LinearLayout.() -> Unit) {
        if (box.tag == key) return
        box.tag = key
        box.removeAllViews()
        box.build()
    }

    // ── data helpers ──
    private fun invalidateData() { histCache = null; rowsCache = null }

    private fun rows(): List<Reading> {
        val now = System.currentTimeMillis()
        val c = rowsCache
        if (c != null && now - rowsTime < 4000) return c
        val r = db.all()
        rowsCache = r; rowsTime = now
        return r
    }

    private fun fRows(): List<Reading> = rows().filter { filterIdx == 0 || it.net == filters[filterIdx] }

    private fun healthItems(): List<Triple<String, Boolean, String>> {
        val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        val bt = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        val nfc = NfcAdapter.getDefaultAdapter(this)
        val dbm = mobileDbm()
        val all = sm.getSensorList(Sensor.TYPE_ALL)
        val liveN = all.count { (counts[it] ?: 0) > 0 }
        val miss = missingPerms().size
        val l = loc
        return listOf(
            Triple("Wi-Fi", wm.isWifiEnabled, "${wm.connectionInfo?.rssi ?: "-"} dBm"),
            Triple("Internet", caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true, ""),
            Triple("Mobile signal", dbm != null, dbm?.let { "$it dBm" } ?: "none"),
            Triple("GPS fix", l != null, if (l != null) "±${l.accuracy.roundToInt()} m" else "$sats sats"),
            Triple("Bluetooth", bt?.isEnabled == true, if (bt == null) "no hardware" else ""),
            Triple("NFC", nfc?.isEnabled == true, if (nfc == null) "no hardware" else ""),
            Triple("Sensors live", liveN > 0, "$liveN / ${all.size}"),
            Triple("Usage access", hasUsage(), ""),
            Triple("Permissions", miss == 0, if (miss == 0) "all granted" else "$miss missing")
        )
    }

    private fun usage(): List<Pair<String, Long>> {
        val now = System.currentTimeMillis()
        if (now - usageTime < 30000 && usageCache.isNotEmpty()) return usageCache
        usageTime = now
        val usm = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val m = usm.queryAndAggregateUsageStats(cal.timeInMillis, now)
        usageTotal = m.values.sumOf { it.totalTimeInForeground }
        usageCache = m.values.filter { it.totalTimeInForeground > 0 }
            .sortedByDescending { it.totalTimeInForeground }.take(5).map {
                val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(it.packageName, 0)).toString() } catch (_: Exception) { it.packageName }
                label to it.totalTimeInForeground
            }
        return usageCache
    }

    // ── small view builders ──
    private fun healthRow(name: String, ok: Boolean, detail: String): LinearLayout {
        val r = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, ctx.dp(6), 0, ctx.dp(6)) }
        r.addView(View(ctx).apply { background = rounded(if (ok) C.GREEN else C.RED, ctx.dpf(6f)) }, lp(ctx.dp(12), ctx.dp(12)).apply { marginEnd = ctx.dp(12) })
        r.addView(txt(ctx, name, 14f), lp(0, -2, 1f))
        if (detail.isNotEmpty()) r.addView(txt(ctx, detail, 12f, C.MUTED))
        r.addView(chip(ctx, if (ok) "OK" else "CHECK", if (ok) C.GREEN else C.RED, if (ok) C.GREEN_BG else C.RED_BG), lp(-2, -2).apply { marginStart = ctx.dp(8) })
        return r
    }

    private fun deltaRow(label: String, a: Double?, b: Double?, lowerBetter: Boolean, dec: Int, unit: String): LinearLayout {
        val r = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, ctx.dp(6), 0, ctx.dp(6)) }
        r.addView(txt(ctx, label, 14f), lp(0, -2, 1f))
        r.addView(txt(ctx, "${Analysis.f(a, dec)} vs ${Analysis.f(b, dec)} $unit", 12f, C.MUTED))
        val ch = if (a == null || b == null || b == 0.0) 0.0 else (a - b) / b * 100
        val good = if (lowerBetter) ch <= 0 else ch >= 0
        r.addView(chip(ctx, String.format(Locale.US, "%+.0f%%", ch), if (good) C.GREEN else C.RED, if (good) C.GREEN_BG else C.RED_BG), lp(-2, -2).apply { marginStart = ctx.dp(8) })
        return r
    }

    private fun recentRow(x: Reading): LinearLayout {
        val r = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, ctx.dp(7), 0, ctx.dp(7)) }
        val wifi = x.net == "Wi-Fi"
        r.addView(chip(ctx, x.net, if (wifi) C.INDIGO else C.AMBER, if (wifi) C.INDIGO_BG else C.AMBER_BG), lp(-2, -2).apply { marginEnd = ctx.dp(10) })
        val mid = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        mid.addView(txt(ctx, x.place.take(24), 13f))
        mid.addView(txt(ctx, SimpleDateFormat("MMM d, HH:mm", Locale.US).format(Date(x.ts)), 11f, C.MUTED))
        r.addView(mid, lp(0, -2, 1f))
        r.addView(txt(ctx, if (x.kind == "speed") "↓${Analysis.f(x.down, 0)}  ↑${Analysis.f(x.up, 0)}" else "${x.dbm ?: "-"} dBm", 13f, C.TEXT, true))
        return r
    }

    private fun statBox(parent: LinearLayout, title: String, color: Int, bg: Int): TextView {
        val b = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = rounded(bg, ctx.dpf(12f)); setPadding(ctx.dp(6), ctx.dp(10), ctx.dp(6), ctx.dp(10)) }
        val v = txt(ctx, "–", 18f, color, true)
        b.addView(v); b.addView(txt(ctx, title, 11f, C.MUTED))
        parent.addView(b, lp(0, -2, 1f).apply { marginEnd = ctx.dp(4); marginStart = ctx.dp(4) })
        return v
    }

    private fun wrapRing(ring: RingView, label: String): LinearLayout {
        val w = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        w.addView(ring, lp(ctx.dp(96), ctx.dp(96)))
        w.addView(txt(ctx, label, 12f, C.MUTED, true), lp(-2, -2).apply { topMargin = ctx.dp(4) })
        return w
    }

    private fun legend(a: String, ca: Int, b: String, cb: Int): LinearLayout {
        val l = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, ctx.dp(6), 0, 0) }
        l.addView(txt(ctx, "● $a", 12f, ca, true), lp(-2, -2).apply { marginEnd = ctx.dp(14) })
        l.addView(txt(ctx, "● $b", 12f, cb, true))
        return l
    }

    // ── HOME ──
    private fun buildHome() {
        val p = newPage()
        val white70 = Color.parseColor("#CCFFFFFF")
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(C.INDIGO, C.VIOLET)).apply { cornerRadius = dpf(22f) }
            elevation = dpf(4f)
            setPadding(dp(18), dp(18), dp(18), dp(18))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) }
        }
        val ring = RingView(this).apply { trackColor = Color.parseColor("#33FFFFFF"); textColor = Color.WHITE; subColor = white70 }
        hero.addView(ring, lp(dp(100), dp(100)))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), 0, 0, 0) }
        val t2 = txt(this, "", 20f, Color.WHITE, true)
        col.addView(txt(this, "Phone health", 13f, white70, true))
        col.addView(t2)
        col.addView(txt(this, "${Build.MANUFACTURER} ${Build.MODEL}", 12f, white70))
        hero.addView(col, lp(0, -2, 1f))
        p.addView(hero)
        onTick {
            val h = healthItems()
            val ok = h.count { it.second }
            val f = ok / h.size.toFloat()
            ring.set(f, "${(f * 100).roundToInt()}%", "score", Color.WHITE)
            t2.text = "$ok of ${h.size} checks OK"
        }

        val sig = card(this, "SIGNALS", C.TEAL)
        val wifiRow = MeterRow(this, "Wi-Fi"); val cellRow = MeterRow(this, "Mobile network"); val gpsRow = MeterRow(this, "GPS")
        sig.addView(wifiRow.root); sig.addView(cellRow.root); sig.addView(gpsRow.root)
        p.addView(sig)
        onTick {
            val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
            val rssi = wm.connectionInfo?.rssi ?: -127
            val wOn = wm.isWifiEnabled && rssi > -127
            val wf = if (wOn) ((rssi + 100) / 60f).coerceIn(0.05f, 1f) else 0f
            wifiRow.set(wf, if (wOn) "${qLabel(wf)} · $rssi dBm" else "Not connected", if (wOn) qColor(wf) else C.MUTED)
            val d = mobileDbm()
            val cf = if (d != null) ((d + 120) / 60f).coerceIn(0.05f, 1f) else 0f
            cellRow.set(cf, if (d != null) "${qLabel(cf)} · $d dBm" else "No signal / permission", if (d != null) qColor(cf) else C.MUTED)
            val l = loc
            val gf = if (l != null) (1f - l.accuracy / 40f).coerceIn(0.05f, 1f) else 0f
            gpsRow.set(gf, if (l != null) "${qLabel(gf)} · ±${l.accuracy.roundToInt()} m · $satsUsed/$sats" else "No fix · $sats sats seen", if (l != null) qColor(gf) else C.MUTED)
        }

        val hc = card(this, "HEALTH CHECK", C.GREEN)
        val hbox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        hc.addView(hbox); p.addView(hc)
        onTick {
            val items = healthItems()
            refill(hbox, items.joinToString("|") { "${it.first}${it.second}${it.third}" }) {
                items.forEach { (n, ok, d) -> addView(healthRow(n, ok, d)) }
            }
        }

        val bm = card(this, "BATTERY AND MEMORY", C.AMBER)
        val rr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val bRing = RingView(this); val mRing = RingView(this)
        rr.addView(wrapRing(bRing, "Battery"), lp(0, -2, 1f))
        rr.addView(wrapRing(mRing, "RAM used"), lp(0, -2, 1f))
        bm.addView(rr, lp(-1, -2).apply { bottomMargin = dp(14) })
        val stRow = MeterRow(this, "Storage")
        bm.addView(stRow.root)
        p.addView(bm)
        onTick {
            val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val lvl = bi?.let { it.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / maxOf(1, it.getIntExtra(BatteryManager.EXTRA_SCALE, 100)) } ?: 0
            val temp = (bi?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
            val plugged = (bi?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) > 0
            bRing.set(lvl / 100f, "$lvl%", if (plugged) "charging" else "%.1f°C".format(Locale.US, temp),
                if (lvl < 20) C.RED else if (lvl < 50) C.AMBER else C.GREEN)
            val mi = ActivityManager.MemoryInfo()
            (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
            val used = 1f - mi.availMem / mi.totalMem.toFloat()
            mRing.set(used, "${(used * 100).roundToInt()}%", gb(mi.totalMem), if (used > 0.85f) C.RED else if (used > 0.7f) C.AMBER else C.TEAL)
            val st = StatFs(Environment.getDataDirectory().path)
            val su = 1f - st.availableBytes / st.totalBytes.toFloat()
            stRow.set(su, "${gb(st.availableBytes)} free of ${gb(st.totalBytes)}", if (su > 0.9f) C.RED else if (su > 0.75f) C.AMBER else C.INDIGO)
        }

        val sc = card(this, "SENSORS", C.TEAL)
        val sRow = MeterRow(this, "Sensors reporting data")
        val sBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        sc.addView(sRow.root); sc.addView(sBox); p.addView(sc)
        onTick {
            val all = sm.getSensorList(Sensor.TYPE_ALL)
            val live = all.filter { (counts[it] ?: 0) > 0 }
            val f = if (all.isEmpty()) 0f else live.size / all.size.toFloat()
            sRow.set(f, "${live.size} / ${all.size} live", if (f > 0.7f) C.GREEN else if (f > 0.4f) C.AMBER else C.RED)
            sBox.removeAllViews()
            live.take(4).forEach { s ->
                val v = values[s]?.take(3)?.joinToString(", ") { "%.2f".format(Locale.US, it) } ?: ""
                val r = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, ctx.dp(3), 0, ctx.dp(3)) }
                r.addView(txt(ctx, s.name.take(22), 12f, C.MUTED), lp(0, -2, 1f))
                r.addView(txt(ctx, v, 12f, C.TEXT, true))
                sBox.addView(r)
            }
        }

        val tc = card(this, "SCREEN TIME TODAY", C.VIOLET)
        val big = txt(this, "–", 28f, C.TEXT, true)
        val sub = txt(this, "", 12f, C.MUTED)
        val tbox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(10), 0, 0) }
        val grant = pill(this, "Enable usage access", C.VIOLET) { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        tc.addView(big); tc.addView(sub); tc.addView(tbox); tc.addView(grant, lp(-1, -2).apply { topMargin = dp(10) })
        p.addView(tc)
        onTick {
            if (!hasUsage()) {
                big.text = "–"; sub.text = "Usage access needed"; grant.visibility = View.VISIBLE; tbox.removeAllViews(); tbox.tag = null
            } else {
                grant.visibility = View.GONE
                val u = usage()
                big.text = dur(usageTotal); sub.text = "across apps today"
                val top = u.firstOrNull()?.second ?: 1L
                refill(tbox, u.joinToString("|") { "${it.first}${it.second}" }) {
                    u.forEach { (n, ms) ->
                        val r = MeterRow(ctx, n.take(24))
                        r.set(ms / top.toFloat(), dur(ms), C.VIOLET)
                        addView(r.root)
                    }
                }
            }
        }
    }

    // ── SPEED ──
    private fun buildSpeed() {
        val p = newPage()
        val gc = card(this, "INTERNET SPEED", C.INDIGO)
        val gauge = GaugeView(this)
        gc.addView(gauge, lp(-1, -2))
        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val pingV = statBox(stats, "Ping ms", C.AMBER, C.AMBER_BG)
        val upV = statBox(stats, "Upload Mbps", C.TEAL, C.TEAL_BG)
        val jitV = statBox(stats, "Jitter ms", C.VIOLET, C.VIOLET_BG)
        gc.addView(stats, lp(-1, -2).apply { topMargin = dp(6) })
        val statusTv = txt(this, "", 12f, C.MUTED)
        statusTv.gravity = Gravity.CENTER
        gc.addView(statusTv, lp(-1, -2).apply { topMargin = dp(12) })
        val start = pill(this, "Start speed test") { startSpeedTest() }
        gc.addView(start, lp(-1, -2).apply { topMargin = dp(10) })
        p.addView(gc)
        onTick {
            if (testing) {
                gauge.caption = SpeedTest.phase.ifEmpty { "Starting" }
                gauge.setValue(SpeedTest.liveMbps.toFloat(), 300)
            } else {
                gauge.caption = "Download"
                gauge.setValue((lastSpeed?.downMbps ?: 0.0).toFloat())
            }
            gauge.invalidate()
            start.text = if (testing) "Testing…" else "Start speed test"
            start.alpha = if (testing) 0.6f else 1f
            statusTv.text = if (speedStatus.isEmpty()) "Measures ping, download and upload" else speedStatus
            lastSpeed?.let {
                pingV.text = "%.0f".format(Locale.US, it.pingMs)
                upV.text = "%.1f".format(Locale.US, it.upMbps)
                jitV.text = "%.0f".format(Locale.US, it.jitterMs)
            }
        }

        val tr = card(this, "TREND (LAST 12 TESTS)", C.TEAL)
        val line = LineChartView(this)
        tr.addView(line, lp(-1, -2)); tr.addView(legend("Download", C.INDIGO, "Upload", C.TEAL))
        p.addView(tr)
        onTick {
            val t = fRows().filter { it.kind == "speed" && it.down != null }.take(12).reversed()
            line.setData(listOf(
                t.map { (it.down ?: 0.0).toFloat() } to C.INDIGO,
                t.map { (it.up ?: 0.0).toFloat() } to C.TEAL
            ))
        }

        val lc = card(this, "LATEST VS PREVIOUS", C.AMBER)
        val lbox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        lc.addView(lbox); p.addView(lc)
        onTick {
            val t = fRows().filter { it.kind == "speed" && it.down != null }
            refill(lbox, t.take(2).joinToString("|") { "${it.ts}" }) {
                if (t.size < 2) addView(txt(ctx, "Run two tests to compare.", 13f, C.MUTED)) else {
                    addView(deltaRow("Download", t[0].down, t[1].down, false, 1, "Mbps"))
                    addView(deltaRow("Upload", t[0].up, t[1].up, false, 1, "Mbps"))
                    addView(deltaRow("Ping", t[0].ping, t[1].ping, true, 0, "ms"))
                }
            }
        }

        val rc = card(this, "RECENT", C.INDIGO)
        val rbox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        rc.addView(rbox); p.addView(rc)
        onTick {
            val r = fRows().take(5)
            refill(rbox, r.joinToString("|") { "${it.ts}" }) {
                if (r.isEmpty()) addView(txt(ctx, "No readings yet.", 13f, C.MUTED)) else r.forEach { addView(recentRow(it)) }
            }
        }
    }

    // ── COMPARE ──
    private fun buildCompare() {
        val p = newPage()
        val fr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) } }
        val chips = ArrayList<TextView>()
        filters.forEachIndexed { i, n ->
            val t = txt(this, n, 13f, C.INDIGO, true)
            t.gravity = Gravity.CENTER
            t.setPadding(0, dp(10), 0, dp(10))
            t.setOnClickListener { filterIdx = i; refreshUi() }
            chips.add(t)
            fr.addView(t, lp(0, -2, 1f).apply { marginEnd = dp(6) })
        }
        p.addView(fr)
        onTick {
            chips.forEachIndexed { i, t ->
                val on = i == filterIdx
                t.background = rounded(if (on) C.INDIGO else C.INDIGO_BG, ctx.dpf(20f))
                t.setTextColor(if (on) Color.WHITE else C.INDIGO)
            }
        }

        val parts = listOf("Morning", "Afternoon", "Evening", "Night")
        val tc = card(this, "BY TIME OF DAY", C.INDIGO)
        val tBar = BarChartView(this)
        val tBest = txt(this, "", 12f, C.MUTED)
        tc.addView(tBar, lp(-1, -2)); tc.addView(legend("Download", C.INDIGO, "Upload", C.TEAL)); tc.addView(tBest, lp(-2, -2).apply { topMargin = dp(6) })
        p.addView(tc)
        onTick {
            val d = fRows()
            val g = parts.map { pt ->
                val r = d.filter { Analysis.part(it.ts) == pt }
                BarGroup(pt, (Analysis.avg(r.map { it.down }) ?: 0.0).toFloat(), (Analysis.avg(r.map { it.up }) ?: 0.0).toFloat())
            }
            val bi = g.indexOfFirst { it.a == g.maxOf { x -> x.a } && it.a > 0f }
            tBar.setData(g, bi)
            tBest.text = if (bi >= 0) "★ Fastest: ${g[bi].label} (↓ ${g[bi].a.roundToInt()} Mbps)" else "Not enough data"
        }

        val dc = card(this, "BY DAY (LAST 7)", C.TEAL)
        val dLine = LineChartView(this)
        dc.addView(dLine, lp(-1, -2)); dc.addView(legend("Avg download", C.INDIGO, "Avg upload", C.TEAL))
        p.addView(dc)
        onTick {
            val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val days = fRows().groupBy { fmt.format(Date(it.ts)) }.entries.take(7).reversed()
            dLine.setData(listOf(
                days.map { (Analysis.avg(it.value.map { r -> r.down }) ?: 0.0).toFloat() } to C.INDIGO,
                days.map { (Analysis.avg(it.value.map { r -> r.up }) ?: 0.0).toFloat() } to C.TEAL
            ))
        }

        val lc = card(this, "BY LOCATION", C.VIOLET)
        val lBar = BarChartView(this)
        val lList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, 0) }
        lc.addView(lBar, lp(-1, -2)); lc.addView(legend("Download", C.INDIGO, "Upload", C.TEAL)); lc.addView(lList)
        p.addView(lc)
        onTick {
            val d = fRows().filter { it.lat != null && it.lon != null }
            val g = d.groupBy { Analysis.key(it.lat!!, it.lon!!) }.entries
                .sortedByDescending { Analysis.avg(it.value.map { r -> r.down }) ?: -1.0 }.take(5)
            lBar.setData(g.map {
                BarGroup(it.value.first().place.substringBefore(",").take(10),
                    (Analysis.avg(it.value.map { r -> r.down }) ?: 0.0).toFloat(),
                    (Analysis.avg(it.value.map { r -> r.up }) ?: 0.0).toFloat())
            }, if (g.isEmpty()) -1 else 0)
            refill(lList, g.joinToString("|") { it.key + it.value.size }) {
                g.forEachIndexed { i, e ->
                    val r = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, ctx.dp(5), 0, ctx.dp(5)) }
                    r.addView(txt(ctx, e.value.first().place.take(24), 13f), lp(0, -2, 1f))
                    r.addView(txt(ctx, "${e.value.size} tests", 11f, C.MUTED), lp(-2, -2).apply { marginEnd = ctx.dp(8) })
                    if (g.size > 1 && i == 0) r.addView(chip(ctx, "★ best", C.GREEN, C.GREEN_BG))
                    else if (g.size > 1 && i == g.size - 1) r.addView(chip(ctx, "▼ worst", C.RED, C.RED_BG))
                    addView(r)
                }
            }
        }

        val hc = card(this, "THIS LOCATION", C.AMBER)
        val hText = txt(this, "", 13f, C.MUTED)
        val hBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        hc.addView(hText); hc.addView(hBox)
        p.addView(hc)
        onTick {
            val l = loc
            if (l == null) { hText.text = "Waiting for a GPS fix…"; hBox.removeAllViews(); hBox.tag = null } else {
                val d = fRows().filter { it.lat != null && it.lon != null }
                val k = Analysis.key(l.latitude, l.longitude)
                val here = d.filter { Analysis.key(it.lat!!, it.lon!!) == k }
                hText.text = if (here.isEmpty()) "No readings here yet. Run a speed test." else "${here.size} readings at this spot"
                refill(hBox, "${here.size}|${d.size}") {
                    if (here.isNotEmpty()) {
                        addView(deltaRow("Download vs overall", Analysis.avg(here.map { it.down }), Analysis.avg(d.map { it.down }), false, 1, "Mbps"))
                        addView(deltaRow("Ping vs overall", Analysis.avg(here.map { it.ping }), Analysis.avg(d.map { it.ping }), true, 0, "ms"))
                    }
                }
            }
        }

        val dataCard = card(this, "DATA", C.INDIGO)
        dataCard.addView(pill(this, "Save snapshot", C.INDIGO) { saveSnapshot() })
        dataCard.addView(pill(this, "Copy CSV", C.INDIGO_BG, C.INDIGO) {
            Thread {
                val csv = db.csv()
                runOnUiThread {
                    (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("history", csv))
                    Toast.makeText(this, "History CSV copied", Toast.LENGTH_SHORT).show()
                }
            }.start()
        }, lp(-1, -2).apply { topMargin = dp(8) })
        dataCard.addView(pill(this, "Clear history", C.RED_BG, C.RED) {
            AlertDialog.Builder(this).setTitle("Clear history?")
                .setMessage("Deletes all saved speed tests and snapshots.")
                .setPositiveButton("Clear") { _, _ -> Thread { db.clear(); invalidateData() }.start() }
                .setNegativeButton("Cancel", null).show()
        }, lp(-1, -2).apply { topMargin = dp(8) })
        p.addView(dataCard)
    }

    // ── DETAILS ──
    private fun buildDetails() {
        val p = newPage()
        val c = card(this, "ACTIONS", C.INDIGO)
        c.addView(pill(this, "Grant permissions") { requestAll() })
        c.addView(pill(this, "Usage access settings", C.INDIGO_BG, C.INDIGO) { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }, lp(-1, -2).apply { topMargin = dp(8) })
        c.addView(pill(this, "Copy full report", C.INDIGO_BG, C.INDIGO) {
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("report", buildReport()))
            Toast.makeText(this, "Report copied", Toast.LENGTH_SHORT).show()
        }, lp(-1, -2).apply { topMargin = dp(8) })
        p.addView(c)
        val rc = card(this, "FULL REPORT", C.TEAL)
        tv = TextView(this).apply { typeface = Typeface.MONOSPACE; textSize = 11f; setTextColor(C.TEXT) }
        rc.addView(tv)
        p.addView(rc)
    }

    override fun onResume() {
        super.onResume()
        restartListeners()
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
        stopListeners()
    }

    // ───────────────────────── Permissions ─────────────────────────
    private fun wanted(): List<String> {
        val l = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.ACTIVITY_RECOGNITION,
            Manifest.permission.BODY_SENSORS
        )
        if (Build.VERSION.SDK_INT >= 31) {
            l += Manifest.permission.BLUETOOTH_CONNECT
            l += Manifest.permission.BLUETOOTH_SCAN
        }
        if (Build.VERSION.SDK_INT >= 33) l += Manifest.permission.NEARBY_WIFI_DEVICES
        return l
    }

    private fun has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun missingPerms() = wanted().filter { !has(it) }
    private fun requestAll() {
        val m = missingPerms()
        if (m.isEmpty()) Toast.makeText(this, "All runtime permissions granted", Toast.LENGTH_SHORT).show()
        else requestPermissions(m.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        restartListeners()
    }

    private fun hasUsage(): Boolean {
        val ao = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        return ao.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) ==
            AppOpsManager.MODE_ALLOWED
    }

    // ───────────────────────── Listeners ─────────────────────────
    private fun restartListeners() {
        stopListeners()
        for (s in sm.getSensorList(Sensor.TYPE_ALL)) {
            try {
                if (s.reportingMode == Sensor.REPORTING_MODE_ONE_SHOT) {
                    regState[s] = if (sm.requestTriggerSensor(trigger, s)) "ONE-SHOT (waiting for trigger)" else "ONE-SHOT (not available)"
                } else {
                    val ok = sm.registerListener(this, s, SensorManager.SENSOR_DELAY_NORMAL)
                    regState[s] = if (ok) "OK" else "REGISTER FAILED"
                }
            } catch (e: SecurityException) {
                regState[s] = "PERMISSION DENIED"
            } catch (e: Exception) {
                regState[s] = "ERROR ${e.javaClass.simpleName}"
            }
        }
        if (has(Manifest.permission.ACCESS_FINE_LOCATION)) {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
                try {
                    if (lm.allProviders.contains(p)) lm.requestLocationUpdates(p, 2000L, 0f, this)
                } catch (_: Exception) {}
            }
            try {
                lm.registerGnssStatusCallback(gnss, handler)
                gnssRegistered = true
            } catch (_: Exception) {}
        }
    }

    private fun stopListeners() {
        sm.unregisterListener(this)
        for (s in sm.getSensorList(Sensor.TYPE_ALL)) {
            try { if (s.reportingMode == Sensor.REPORTING_MODE_ONE_SHOT) sm.cancelTriggerSensor(trigger, s) } catch (_: Exception) {}
        }
        try {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            lm.removeUpdates(this)
            if (gnssRegistered) lm.unregisterGnssStatusCallback(gnss)
        } catch (_: Exception) {}
        gnssRegistered = false
    }

    override fun onSensorChanged(e: SensorEvent) {
        values[e.sensor] = e.values.clone()
        counts[e.sensor] = (counts[e.sensor] ?: 0) + 1
    }
    override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {}

    override fun onLocationChanged(l: Location) { loc = l; locTime = System.currentTimeMillis() }
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}

    // ───────────────────────── Speed test + history ─────────────────────────
    private fun startSpeedTest() {
        if (testing) { Toast.makeText(this, "Test already running", Toast.LENGTH_SHORT).show(); return }
        testing = true
        speedStatus = "Starting..."
        Thread {
            try {
                val r = SpeedTest.run { speedStatus = it }
                lastSpeed = r
                speedStatus = "Saving..."
                db.insert(makeReading("speed", r))
                invalidateData()
                speedStatus = "Done"
            } catch (e: Exception) {
                speedStatus = "Failed: ${e.javaClass.simpleName} (${e.message}) - check internet"
            }
            testing = false
        }.start()
    }

    private fun saveSnapshot() {
        Thread {
            db.insert(makeReading("snap", null))
            invalidateData()
            runOnUiThread { Toast.makeText(this, "Snapshot saved", Toast.LENGTH_SHORT).show() }
        }.start()
    }

    private fun bestLocation(): Location? {
        loc?.let { return it }
        if (!has(Manifest.permission.ACCESS_FINE_LOCATION)) return null
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        return listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            .mapNotNull { try { lm.getLastKnownLocation(it) } catch (_: Exception) { null } }
            .maxByOrNull { it.time }
    }

    private fun placeName(l: Location?): String {
        if (l == null) return "Unknown location"
        val fallback = "%.4f, %.4f".format(Locale.US, l.latitude, l.longitude)
        return try {
            if (!Geocoder.isPresent()) fallback else {
                val a = Geocoder(this, Locale.getDefault()).getFromLocation(l.latitude, l.longitude, 1)?.firstOrNull()
                if (a == null) fallback
                else listOfNotNull(a.thoroughfare ?: a.subLocality, a.locality).joinToString(", ").ifEmpty { fallback }
            }
        } catch (_: Exception) { fallback }
    }

    private fun makeReading(kind: String, r: SpeedResult?): Reading {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        val tm = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
        val wifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        val cell = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
        val net = if (wifi) "Wi-Fi" else if (cell) "Mobile" else "None"
        val carrier = if (wifi) (wm.connectionInfo?.ssid ?: "").trim('"')
        else tm.networkOperatorName + if (has(Manifest.permission.READ_PHONE_STATE)) " " + netTypeName(tm.dataNetworkType) else ""
        val dbm = if (wifi) wm.connectionInfo?.rssi else mobileDbm()
        val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val batt = bi?.let { it.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / maxOf(1, it.getIntExtra(BatteryManager.EXTRA_SCALE, 100)) } ?: 0
        val l = bestLocation()
        return Reading(
            System.currentTimeMillis(), l?.latitude, l?.longitude, placeName(l), net, carrier, dbm,
            r?.downMbps, r?.upMbps, r?.pingMs, r?.jitterMs, batt, kind
        )
    }

    private fun historyText(): String {
        val now = System.currentTimeMillis()
        val c = histCache
        if (c != null && now - histTime < 10_000) return c
        val t = Analysis.build(db.all(), filters[filterIdx], loc)
        histCache = t; histTime = now
        return t
    }

    // ───────────────────────── Report helpers ─────────────────────────
    private fun StringBuilder.kv(k: String, v: Any?) { append("  ").append(k.padEnd(18)).append(": ").append(v).append('\n') }
    private fun StringBuilder.chk(name: String, ok: Boolean, extra: String = "") {
        append("  ").append(if (ok) "✓ " else "✗ ").append(name)
        if (extra.isNotEmpty()) append("  (").append(extra).append(")")
        append('\n')
    }
    private fun section(sb: StringBuilder, title: String, body: StringBuilder.() -> Unit) {
        sb.append("\n━━ ").append(title).append(" ━━\n")
        try { sb.body() } catch (e: Exception) { sb.append("  error: ${e.javaClass.simpleName}: ${e.message}\n") }
    }
    private fun dur(ms: Long) = "${ms / 3600000}h ${ms / 60000 % 60}m"
    private fun mb(b: Long) = "%.0f MB".format(b / 1048576.0)
    private fun gb(b: Long) = "%.2f GB".format(b / 1073741824.0)

    private fun netTypeName(t: Int) = when (t) {
        TelephonyManager.NETWORK_TYPE_NR -> "5G NR"
        TelephonyManager.NETWORK_TYPE_LTE -> "4G LTE"
        TelephonyManager.NETWORK_TYPE_HSPAP -> "3G HSPA+"
        TelephonyManager.NETWORK_TYPE_HSPA, TelephonyManager.NETWORK_TYPE_HSDPA, TelephonyManager.NETWORK_TYPE_HSUPA -> "3G HSPA"
        TelephonyManager.NETWORK_TYPE_UMTS -> "3G UMTS"
        TelephonyManager.NETWORK_TYPE_EDGE -> "2G EDGE"
        TelephonyManager.NETWORK_TYPE_GPRS -> "2G GPRS"
        TelephonyManager.NETWORK_TYPE_UNKNOWN -> "unknown/none"
        else -> "type $t"
    }

    private fun mobileDbm(): Int? {
        val tm = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
        val d = tm.signalStrength?.cellSignalStrengths?.firstOrNull()?.dbm
        return if (d == null || d == Int.MAX_VALUE) null else d
    }

    // ───────────────────────── Report ─────────────────────────
    private fun buildReport(): String {
        val sb = StringBuilder()
        val now = System.currentTimeMillis()
        sb.append("PHONE DIAGNOSTICS  ").append(SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(now))).append('\n')

        val allSensors = sm.getSensorList(Sensor.TYPE_ALL)
        val live = allSensors.count { (counts[it] ?: 0) > 0 }

        section(sb, "QUICK HEALTH CHECK") {
            val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
            val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            val bt = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
            val nfc = NfcAdapter.getDefaultAdapter(this@MainActivity)
            val dbm = mobileDbm()
            chk("Wi-Fi radio on", wm.isWifiEnabled, "${wm.connectionInfo?.rssi ?: "-"} dBm")
            chk("Internet validated", caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true)
            chk("Mobile signal", dbm != null, dbm?.let { "$it dBm" } ?: "none / permission needed")
            chk("GPS fix", loc != null, loc?.let { "±${"%.0f".format(it.accuracy)} m, $satsUsed/$sats sats" } ?: "sats visible: $sats")
            chk("Bluetooth on", bt?.isEnabled == true, if (bt == null) "no hardware" else "")
            chk("NFC on", nfc?.isEnabled == true, if (nfc == null) "no hardware" else "")
            chk("Sensors live", live > 0, "$live / ${allSensors.size}")
            chk("Usage access (screen time)", hasUsage())
            val miss = missingPerms()
            chk("Runtime permissions", miss.isEmpty(), if (miss.isEmpty()) "all granted" else "missing ${miss.size}")
        }

        section(sb, "INTERNET SPEED TEST") {
            kv("Status", if (speedStatus.isEmpty()) "tap [Speed test]" else speedStatus)
            lastSpeed?.let {
                kv("Download", "${"%.1f".format(it.downMbps)} Mbps")
                kv("Upload", "${"%.1f".format(it.upMbps)} Mbps")
                kv("Ping / jitter", "${"%.0f".format(it.pingMs)} / ${"%.0f".format(it.jitterMs)} ms")
            }
            append("  Note: uses up to ~100+ MB; avoid on mobile data.\n")
        }
        sb.append(historyText())

        section(sb, "DEVICE") {
            kv("Model", "${Build.MANUFACTURER} ${Build.MODEL}")
            kv("Brand/Device", "${Build.BRAND} / ${Build.DEVICE}")
            kv("Hardware/Board", "${Build.HARDWARE} / ${Build.BOARD}")
            kv("Android", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
            kv("Security patch", Build.VERSION.SECURITY_PATCH)
            kv("Build", Build.DISPLAY)
            kv("ABIs", Build.SUPPORTED_ABIS.joinToString())
            kv("CPU cores", Runtime.getRuntime().availableProcessors())
            kv("Android ID", Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID))
            kv("Uptime", dur(SystemClock.elapsedRealtime()))
            kv("Locale/TZ", "${Locale.getDefault()} / ${TimeZone.getDefault().id}")
        }

        section(sb, "BATTERY") {
            val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
            if (i != null) {
                val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                kv("Level", "${lvl * 100 / scale}%")
                kv("Status", when (i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)) {
                    BatteryManager.BATTERY_STATUS_CHARGING -> "charging"
                    BatteryManager.BATTERY_STATUS_DISCHARGING -> "discharging"
                    BatteryManager.BATTERY_STATUS_FULL -> "full"
                    BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "not charging"
                    else -> "unknown"
                })
                kv("Plugged", when (i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)) {
                    BatteryManager.BATTERY_PLUGGED_AC -> "AC"
                    BatteryManager.BATTERY_PLUGGED_USB -> "USB"
                    BatteryManager.BATTERY_PLUGGED_WIRELESS -> "wireless"
                    else -> "no"
                })
                kv("Health", when (i.getIntExtra(BatteryManager.EXTRA_HEALTH, -1)) {
                    BatteryManager.BATTERY_HEALTH_GOOD -> "good"
                    BatteryManager.BATTERY_HEALTH_OVERHEAT -> "overheat"
                    BatteryManager.BATTERY_HEALTH_DEAD -> "dead"
                    BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "over voltage"
                    BatteryManager.BATTERY_HEALTH_COLD -> "cold"
                    else -> "unknown"
                })
                kv("Temperature", "${i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0} °C")
                kv("Voltage", "${i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)} mV")
                kv("Technology", i.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY))
            }
            kv("Current now", "${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) / 1000} mA")
            kv("Charge counter", "${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER) / 1000} mAh")
        }

        section(sb, "DISPLAY / MEMORY / STORAGE") {
            val dm = resources.displayMetrics
            kv("Resolution", "${dm.widthPixels} x ${dm.heightPixels}")
            kv("Density", "${dm.densityDpi} dpi (x${dm.density})")
            kv("Refresh rate", "${"%.1f".format(windowManager.defaultDisplay.refreshRate)} Hz")
            val mi = ActivityManager.MemoryInfo()
            (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
            kv("RAM", "${mb(mi.availMem)} free / ${mb(mi.totalMem)}")
            kv("Low memory", mi.lowMemory)
            val st = StatFs(Environment.getDataDirectory().path)
            kv("Storage", "${gb(st.availableBytes)} free / ${gb(st.totalBytes)}")
        }

        section(sb, "MOBILE NETWORK / SIGNAL") {
            val tm = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
            kv("Operator", tm.networkOperatorName)
            kv("MCC/MNC", tm.networkOperator)
            kv("Country", tm.networkCountryIso)
            kv("SIM state", when (tm.simState) {
                TelephonyManager.SIM_STATE_READY -> "ready"
                TelephonyManager.SIM_STATE_ABSENT -> "absent"
                TelephonyManager.SIM_STATE_PIN_REQUIRED -> "PIN required"
                else -> "state ${tm.simState}"
            })
            kv("Roaming", tm.isNetworkRoaming)
            kv("Data type", if (has(Manifest.permission.READ_PHONE_STATE)) netTypeName(tm.dataNetworkType) else "needs phone permission")
            tm.signalStrength?.cellSignalStrengths?.forEach {
                kv(it.javaClass.simpleName.removePrefix("Cell"), "${it.dbm} dBm, level ${it.level}/4, asu ${it.asuLevel}")
            }
            if (has(Manifest.permission.ACCESS_FINE_LOCATION)) {
                val cells: List<CellInfo> = tm.allCellInfo ?: emptyList()
                kv("Visible cells", cells.size)
                cells.take(8).forEach { c ->
                    val (rat, dbm) = when (c) {
                        is CellInfoLte -> "LTE" to c.cellSignalStrength.dbm
                        is CellInfoNr -> "5G NR" to c.cellSignalStrength.dbm
                        is CellInfoGsm -> "GSM" to c.cellSignalStrength.dbm
                        is CellInfoWcdma -> "WCDMA" to c.cellSignalStrength.dbm
                        else -> c.javaClass.simpleName to 0
                    }
                    append("    - $rat ${if (c.isRegistered) "[serving]" else ""} $dbm dBm\n")
                }
            } else kv("Cell list", "needs location permission")
        }

        section(sb, "WI-FI / INTERNET") {
            val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
            val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
            kv("Wi-Fi enabled", wm.isWifiEnabled)
            val w = wm.connectionInfo
            kv("SSID", w?.ssid)
            kv("RSSI", "${w?.rssi} dBm")
            kv("Link speed", "${w?.linkSpeed} Mbps")
            kv("Frequency", "${w?.frequency} MHz")
            kv("5 GHz supported", wm.is5GHzBandSupported)
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            if (caps != null) {
                val t = mutableListOf<String>()
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) t += "Wi-Fi"
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) t += "Cellular"
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_BLUETOOTH)) t += "Bluetooth"
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) t += "Ethernet"
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) t += "VPN"
                kv("Active transport", t.joinToString())
                kv("Internet", caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET))
                kv("Validated", caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED))
                kv("Down/Up est.", "${caps.linkDownstreamBandwidthKbps / 1000} / ${caps.linkUpstreamBandwidthKbps / 1000} Mbps")
            } else kv("Active network", "none")
            try {
                val sr = wm.scanResults.sortedByDescending { it.level }
                kv("Networks nearby", sr.size)
                sr.take(8).forEach { append("    - ${it.SSID.ifEmpty { "<hidden>" }}  ${it.level} dBm  ${it.frequency} MHz\n") }
            } catch (e: SecurityException) { kv("Wi-Fi scan", "needs location permission") }
        }

        section(sb, "BLUETOOTH / NFC") {
            val bt = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
            if (bt == null) kv("Bluetooth", "no hardware") else {
                kv("Enabled", bt.isEnabled)
                kv("BLE supported", packageManager.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE))
                if (Build.VERSION.SDK_INT < 31 || has(Manifest.permission.BLUETOOTH_CONNECT)) {
                    kv("Paired devices", bt.bondedDevices.size)
                    bt.bondedDevices.take(8).forEach { append("    - ${it.name}\n") }
                } else kv("Paired devices", "needs Bluetooth permission")
            }
            val nfc = NfcAdapter.getDefaultAdapter(this@MainActivity)
            kv("NFC", if (nfc == null) "no hardware" else if (nfc.isEnabled) "on" else "off")
        }

        section(sb, "GPS / LOCATION") {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            kv("GPS provider", lm.isProviderEnabled(LocationManager.GPS_PROVIDER))
            kv("Network provider", lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER))
            kv("Satellites", "$satsUsed used / $sats visible")
            val l = loc
            if (l == null) kv("Fix", "none yet (go outdoors, wait ~30s)") else {
                kv("Lat/Lon", "${"%.6f".format(l.latitude)}, ${"%.6f".format(l.longitude)}")
                kv("Accuracy", "±${"%.1f".format(l.accuracy)} m")
                kv("Altitude", "${"%.1f".format(l.altitude)} m")
                kv("Speed", "${"%.1f".format(l.speed * 3.6)} km/h")
                kv("Provider", l.provider)
                kv("Age", "${(now - locTime) / 1000}s")
            }
        }

        section(sb, "CAMERAS / HARDWARE FEATURES") {
            val cmgr = getSystemService(CAMERA_SERVICE) as CameraManager
            cmgr.cameraIdList.forEach { id ->
                val f = cmgr.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING)
                kv("Camera $id", when (f) { CameraCharacteristics.LENS_FACING_BACK -> "back"; CameraCharacteristics.LENS_FACING_FRONT -> "front"; else -> "external" })
            }
            val feats = listOf(
                "camera.flash" to "Flash", "fingerprint" to "Fingerprint", "biometrics.face" to "Face unlock",
                "nfc" to "NFC", "location.gps" to "GPS", "telephony" to "Telephony", "consumerir" to "IR blaster",
                "usb.host" to "USB host", "wifi.rtt" to "Wi-Fi RTT", "uwb" to "UWB", "sensor.barometer" to "Barometer"
            )
            feats.forEach { (k, n) -> chk(n, packageManager.hasSystemFeature("android.hardware.$k")) }
        }

        section(sb, "SENSORS  ($live live / ${allSensors.size} total)") {
            allSensors.forEachIndexed { idx, s ->
                val c = counts[s] ?: 0
                val state = regState[s] ?: "?"
                val mark = if (c > 0) "✓ LIVE" else if (state == "OK") "… WAITING" else "✗ $state"
                append("  [$idx] $mark  ${s.name}\n")
                append("      ${s.stringType.substringAfterLast('.')} | ${s.vendor} | range ${s.maximumRange} | res ${s.resolution} | ${s.power} mA\n")
                values[s]?.let { v -> append("      values: ${v.take(6).joinToString(", ") { "%.3f".format(it) }}  (events: $c)\n") }
            }
        }

        section(sb, "SCREEN TIME") {
            if (!hasUsage()) {
                append("  Usage access not granted.\n  Tap [Usage Access] and enable 'Phone Diagnostics'.\n")
            } else {
                val usm = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
                val cal = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                }
                val dayStart = cal.timeInMillis
                val today = usm.queryAndAggregateUsageStats(dayStart, now)
                val total = today.values.sumOf { it.totalTimeInForeground }
                kv("Today (app time)", dur(total))
                cal.add(Calendar.DAY_OF_YEAR, -6)
                val week = usm.queryAndAggregateUsageStats(cal.timeInMillis, now)
                kv("Last 7 days", dur(week.values.sumOf { it.totalTimeInForeground }))

                var screenOn = 0; var unlocks = 0
                val ev = usm.queryEvents(dayStart, now)
                val e = UsageEvents.Event()
                while (ev.hasNextEvent()) {
                    ev.getNextEvent(e)
                    if (e.eventType == UsageEvents.Event.SCREEN_INTERACTIVE) screenOn++
                    if (e.eventType == UsageEvents.Event.KEYGUARD_HIDDEN) unlocks++
                }
                kv("Screen-on events", screenOn)
                kv("Unlocks", unlocks)
                append("  Top apps today:\n")
                today.values.filter { it.totalTimeInForeground > 0 }
                    .sortedByDescending { it.totalTimeInForeground }.take(15).forEach {
                        val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(it.packageName, 0)) } catch (_: Exception) { it.packageName }
                        append("    ${dur(it.totalTimeInForeground).padEnd(8)} $label\n")
                    }
            }
        }

        section(sb, "PERMISSIONS") {
            wanted().forEach { chk(it.substringAfterLast('.'), has(it)) }
            chk("PACKAGE_USAGE_STATS (special)", hasUsage())
        }
        return sb.toString()
    }
}

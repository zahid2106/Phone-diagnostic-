package com.example.phonediag

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/** Colour palette. */
object C {
    val BG = Color.parseColor("#F3F4F8")
    val CARD = Color.WHITE
    val TEXT = Color.parseColor("#111827")
    val MUTED = Color.parseColor("#6B7280")
    val TRACK = Color.parseColor("#E5E7EB")
    val INDIGO = Color.parseColor("#4F46E5")
    val VIOLET = Color.parseColor("#7C3AED")
    val TEAL = Color.parseColor("#0D9488")
    val GREEN = Color.parseColor("#16A34A")
    val AMBER = Color.parseColor("#F59E0B")
    val RED = Color.parseColor("#DC2626")
    val INDIGO_BG = Color.parseColor("#E0E7FF")
    val TEAL_BG = Color.parseColor("#CCFBF1")
    val VIOLET_BG = Color.parseColor("#EDE9FE")
    val GREEN_BG = Color.parseColor("#DCFCE7")
    val RED_BG = Color.parseColor("#FEE2E2")
    val AMBER_BG = Color.parseColor("#FEF3C7")
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density
fun qColor(f: Float): Int = if (f >= 0.66f) C.GREEN else if (f >= 0.33f) C.AMBER else C.RED
fun qLabel(f: Float): String = if (f >= 0.75f) "Excellent" else if (f >= 0.5f) "Good" else if (f >= 0.25f) "Fair" else "Weak"
fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

fun rounded(color: Int, radius: Float) = GradientDrawable().apply { setColor(color); cornerRadius = radius }

fun txt(ctx: Context, s: String, sp: Float = 14f, color: Int = C.TEXT, bold: Boolean = false): TextView =
    TextView(ctx).apply { text = s; textSize = sp; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD }

fun chip(ctx: Context, label: String, fg: Int, bg: Int): TextView =
    TextView(ctx).apply {
        text = label; textSize = 11f; setTextColor(fg); typeface = Typeface.DEFAULT_BOLD
        background = rounded(bg, ctx.dpf(10f)); setPadding(ctx.dp(10), ctx.dp(3), ctx.dp(10), ctx.dp(3))
    }

fun pill(ctx: Context, label: String, fill: Int = C.INDIGO, fg: Int = Color.WHITE, onClick: () -> Unit): TextView =
    TextView(ctx).apply {
        text = label; textSize = 14f; setTextColor(fg); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        background = rounded(fill, ctx.dpf(26f)); setPadding(ctx.dp(16), ctx.dp(12), ctx.dp(16), ctx.dp(12))
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }
            false
        }
        setOnClickListener { onClick() }
    }

fun card(ctx: Context, title: String? = null, accent: Int = C.INDIGO): LinearLayout {
    val l = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(C.CARD, ctx.dpf(18f))
        elevation = ctx.dpf(3f)
        setPadding(ctx.dp(16), ctx.dp(14), ctx.dp(16), ctx.dp(16))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = ctx.dp(14) }
    }
    if (title != null) {
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(View(ctx).apply { background = rounded(accent, ctx.dpf(4f)) }, lp(ctx.dp(8), ctx.dp(8)).apply { marginEnd = ctx.dp(8) })
        row.addView(txt(ctx, title, 12f, C.MUTED, true))
        l.addView(row, lp(-1, -2).apply { bottomMargin = ctx.dp(10) })
    }
    return l
}

/** Slide-up + fade-in entrance animation. */
fun View.popIn(delay: Long) {
    alpha = 0f
    translationY = context.dpf(18f)
    animate().alpha(1f).translationY(0f).setStartDelay(delay).setDuration(380).setInterpolator(DecelerateInterpolator()).start()
}

// ───────────────────────── Speed gauge ─────────────────────────
class GaugeView(ctx: Context) : View(ctx) {
    var caption = "Download"
    var unit = "Mbps"
    private var shown = 0f
    private var maxV = 100f
    private var target = -1f
    private var anim: ValueAnimator? = null
    private val ev = ArgbEvaluator()
    private val oval = RectF()
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = C.TRACK }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val big = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD; color = C.TEXT }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; color = C.MUTED }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)

    fun setValue(v: Float, ms: Long = 450) {
        if (abs(v - target) < 0.01f) return
        target = v
        maxV = listOf(50f, 100f, 250f, 500f, 1000f, 2000f).firstOrNull { v <= it * 0.92f } ?: 2000f
        anim?.cancel()
        anim = ValueAnimator.ofFloat(shown, v).apply {
            duration = ms
            interpolator = DecelerateInterpolator()
            addUpdateListener { shown = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onMeasure(w: Int, h: Int) {
        val width = getDefaultSize(0, w)
        setMeasuredDimension(width, (width * 0.84f).toInt())
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val sw = w * 0.07f
        track.strokeWidth = sw; arc.strokeWidth = sw
        val r = w / 2f - sw * 1.2f
        val cx = w / 2f
        val cy = r + sw * 1.2f
        oval.set(cx - r, cy - r, cx + r, cy + r)
        canvas.drawArc(oval, 150f, 240f, false, track)
        val f = (shown / maxV).coerceIn(0f, 1f)
        val col = ev.evaluate(f, C.TEAL, C.INDIGO) as Int
        arc.color = col
        if (f > 0f) canvas.drawArc(oval, 150f, 240f * f, false, arc)
        val a = Math.toRadians((150f + 240f * f).toDouble())
        val px = cx + r * cos(a).toFloat()
        val py = cy + r * sin(a).toFloat()
        dot.color = Color.WHITE; canvas.drawCircle(px, py, sw * 0.62f, dot)
        dot.color = col; canvas.drawCircle(px, py, sw * 0.34f, dot)
        big.textSize = w * 0.17f
        small.textSize = w * 0.05f
        val base = cy + big.textSize * 0.25f
        canvas.drawText(String.format("%.1f", shown), cx, base, big)
        canvas.drawText(unit, cx, base + w * 0.08f, small)
        canvas.drawText(caption, cx, base - big.textSize * 0.95f, small)
        small.textSize = w * 0.04f
        val ly = cy + r * 0.5f + sw * 1.4f
        canvas.drawText("0", cx - r * 0.87f, ly, small)
        canvas.drawText(maxV.roundToInt().toString(), cx + r * 0.87f, ly, small)
    }
}

// ───────────────────────── Line chart ─────────────────────────
class LineChartView(ctx: Context) : View(ctx) {
    private var series: List<Pair<List<Float>, Int>> = emptyList()
    private var prog = 1f
    private val grid = Paint().apply { color = C.TRACK; strokeWidth = 2f }
    private val lbl = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = C.MUTED; textSize = ctx.dpf(10f) }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = ctx.dpf(3f); strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dotP = Paint(Paint.ANTI_ALIAS_FLAG)

    fun setData(s: List<Pair<List<Float>, Int>>) {
        if (s == series) return
        series = s
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 800
            interpolator = DecelerateInterpolator()
            addUpdateListener { prog = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(getDefaultSize(0, w), context.dp(170)) }

    override fun onDraw(canvas: Canvas) {
        val l = context.dpf(34f); val r = context.dpf(8f); val t = context.dpf(8f); val b = context.dpf(8f)
        val cw = width - l - r
        val ch = height - t - b
        val maxY = max(1f, (series.flatMap { it.first }.maxOrNull() ?: 1f) * 1.15f)
        for (i in 0..3) {
            val y = t + ch * i / 3f
            canvas.drawLine(l, y, width - r, y, grid)
            canvas.drawText((maxY * (3 - i) / 3f).roundToInt().toString(), 0f, y + context.dpf(3f), lbl)
        }
        if (series.all { it.first.isEmpty() }) {
            lbl.textAlign = Paint.Align.CENTER
            canvas.drawText("No data yet - run a speed test", width / 2f, height / 2f, lbl)
            lbl.textAlign = Paint.Align.LEFT
            return
        }
        canvas.save()
        canvas.clipRect(l - 6f, 0f, l + cw * prog + 6f, height.toFloat())
        for ((vals, color) in series) {
            if (vals.isEmpty()) continue
            val n = vals.size
            fun px(i: Int) = if (n == 1) l + cw / 2f else l + cw * i / (n - 1f)
            fun py(v: Float) = t + ch * (1f - v / maxY)
            val path = Path()
            path.moveTo(px(0), py(vals[0]))
            for (i in 1 until n) {
                val x0 = px(i - 1); val y0 = py(vals[i - 1]); val x1 = px(i); val y1 = py(vals[i])
                val mx = (x0 + x1) / 2f
                path.cubicTo(mx, y0, mx, y1, x1, y1)
            }
            val area = Path(path)
            area.lineTo(px(n - 1), t + ch); area.lineTo(px(0), t + ch); area.close()
            fill.shader = LinearGradient(0f, t, 0f, t + ch, (color and 0x00FFFFFF) or 0x55000000, color and 0x00FFFFFF, Shader.TileMode.CLAMP)
            canvas.drawPath(area, fill)
            line.color = color
            canvas.drawPath(path, line)
            for (i in 0 until n) {
                dotP.color = Color.WHITE; canvas.drawCircle(px(i), py(vals[i]), context.dpf(4f), dotP)
                dotP.color = color; canvas.drawCircle(px(i), py(vals[i]), context.dpf(2.5f), dotP)
            }
        }
        canvas.restore()
    }
}

// ───────────────────────── Bar chart ─────────────────────────
data class BarGroup(val label: String, val a: Float, val b: Float)

class BarChartView(ctx: Context) : View(ctx) {
    var colorA = C.INDIGO
    var colorB = C.TEAL
    private var groups: List<BarGroup> = emptyList()
    private var highlight = -1
    private var prog = 1f
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG)
    private val base = Paint().apply { color = C.TRACK; strokeWidth = 3f }
    private val val_ = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; textSize = ctx.dpf(10f); color = C.TEXT; typeface = Typeface.DEFAULT_BOLD }
    private val lab = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; textSize = ctx.dpf(11f) }
    private val rect = RectF()

    fun setData(g: List<BarGroup>, hl: Int) {
        if (g == groups && hl == highlight) return
        groups = g; highlight = hl
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 700
            interpolator = DecelerateInterpolator()
            addUpdateListener { prog = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(getDefaultSize(0, w), context.dp(190)) }

    override fun onDraw(canvas: Canvas) {
        if (groups.isEmpty()) {
            lab.color = C.MUTED
            canvas.drawText("No data yet", width / 2f, height / 2f, lab)
            return
        }
        val padB = context.dpf(24f); val padT = context.dpf(16f)
        val ch = height - padB - padT
        val baseY = height - padB
        val maxV = max(1f, groups.maxOf { max(it.a, it.b) })
        val gw = width.toFloat() / groups.size
        val bw = gw * 0.26f
        val gap = gw * 0.04f
        canvas.drawLine(0f, baseY, width.toFloat(), baseY, base)
        groups.forEachIndexed { i, g ->
            val cx = gw * i + gw / 2f
            drawBar(canvas, cx - bw - gap / 2f, g.a, maxV, ch, baseY, bw, colorA)
            drawBar(canvas, cx + gap / 2f, g.b, maxV, ch, baseY, bw, colorB)
            lab.color = if (i == highlight) C.INDIGO else C.MUTED
            lab.typeface = if (i == highlight) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            canvas.drawText(g.label.take(10), cx, height - context.dpf(6f), lab)
        }
    }

    private fun drawBar(c: Canvas, x: Float, v: Float, maxV: Float, ch: Float, baseY: Float, bw: Float, color: Int) {
        val h = v / maxV * ch * prog
        bar.color = color
        rect.set(x, baseY - h, x + bw, baseY)
        c.drawRoundRect(rect, context.dpf(5f), context.dpf(5f), bar)
        if (v > 0f && prog > 0.9f) c.drawText(v.roundToInt().toString(), x + bw / 2f, baseY - h - context.dpf(3f), val_)
    }
}

// ───────────────────────── Ring ─────────────────────────
class RingView(ctx: Context) : View(ctx) {
    var trackColor = C.TRACK
    var textColor = C.TEXT
    var subColor = C.MUTED
    private var shown = 0f
    private var target = -1f
    private var col = C.INDIGO
    private var centerText = ""
    private var subText = ""
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val t = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }
    private val oval = RectF()

    fun set(frac: Float, center: String, sub: String, color: Int) {
        centerText = center; subText = sub; col = color
        if (abs(frac - target) > 0.001f) {
            target = frac
            ValueAnimator.ofFloat(shown, frac).apply {
                duration = 700
                interpolator = DecelerateInterpolator()
                addUpdateListener { shown = it.animatedValue as Float; invalidate() }
                start()
            }
        } else invalidate()
    }

    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(getDefaultSize(0, w), getDefaultSize(0, h)) }

    override fun onDraw(canvas: Canvas) {
        val s = min(width, height).toFloat()
        val sw = s * 0.12f
        p.strokeWidth = sw
        oval.set(sw, sw, s - sw, s - sw)
        p.color = trackColor
        canvas.drawArc(oval, 0f, 360f, false, p)
        p.color = col
        canvas.drawArc(oval, -90f, 360f * shown.coerceIn(0f, 1f), false, p)
        t.color = textColor; t.textSize = s * 0.24f
        canvas.drawText(centerText, s / 2f, s / 2f + s * 0.05f, t)
        t.color = subColor; t.textSize = s * 0.11f; t.typeface = Typeface.DEFAULT
        canvas.drawText(subText, s / 2f, s / 2f + s * 0.20f, t)
        t.typeface = Typeface.DEFAULT_BOLD
    }
}

// ───────────────────────── Meter bar ─────────────────────────
class MeterBar(ctx: Context) : View(ctx) {
    private var shown = 0f
    private var target = -1f
    private var col = C.INDIGO
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    fun set(frac: Float, color: Int) {
        col = color
        if (abs(frac - target) > 0.002f) {
            target = frac
            ValueAnimator.ofFloat(shown, frac).apply {
                duration = 600
                interpolator = DecelerateInterpolator()
                addUpdateListener { shown = it.animatedValue as Float; invalidate() }
                start()
            }
        } else invalidate()
    }

    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(getDefaultSize(0, w), context.dp(8)) }

    override fun onDraw(canvas: Canvas) {
        val r = height / 2f
        p.color = C.TRACK
        rect.set(0f, 0f, width.toFloat(), height.toFloat())
        canvas.drawRoundRect(rect, r, r, p)
        if (shown > 0f) {
            p.color = col
            rect.set(0f, 0f, max(height.toFloat(), width * shown.coerceIn(0f, 1f)), height.toFloat())
            canvas.drawRoundRect(rect, r, r, p)
        }
    }
}

/** Label + value + animated bar. */
class MeterRow(ctx: Context, label: String) {
    val root = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = ctx.dp(12) }
    }
    private val value = txt(ctx, "", 13f, C.MUTED, true)
    private val bar = MeterBar(ctx)

    init {
        val top = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        top.addView(txt(ctx, label, 13f, C.TEXT), lp(0, -2, 1f))
        top.addView(value, lp(-2, -2))
        root.addView(top)
        root.addView(bar, lp(-1, ctx.dp(8)).apply { topMargin = ctx.dp(6) })
    }

    fun set(frac: Float, text: String, color: Int) {
        value.text = text
        value.setTextColor(color)
        bar.set(frac, color)
    }
}

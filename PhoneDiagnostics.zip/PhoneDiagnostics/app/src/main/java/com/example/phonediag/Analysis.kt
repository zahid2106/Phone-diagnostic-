package com.example.phonediag

import android.location.Location
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Builds the history + comparison text (by time, by day, by location). */
object Analysis {
    private val partOrder = listOf("Morning", "Afternoon", "Evening", "Night")
    private val L = Locale.US

    fun part(ts: Long): String {
        val h = Calendar.getInstance().apply { timeInMillis = ts }.get(Calendar.HOUR_OF_DAY)
        return when { h < 6 -> "Night"; h < 12 -> "Morning"; h < 18 -> "Afternoon"; else -> "Evening" }
    }

    /** ~220 m grid cell so nearby readings count as the same place. */
    fun key(lat: Double, lon: Double): String =
        String.format(L, "%.3f,%.3f", Math.round(lat * 500) / 500.0, Math.round(lon * 500) / 500.0)

    fun avg(l: List<Double?>): Double? { val n = l.filterNotNull(); return if (n.isEmpty()) null else n.average() }
    fun f(d: Double?, n: Int = 1) = if (d == null) "-" else String.format(L, "%.${n}f", d)
    fun pct(a: Double?, b: Double?) =
        if (a == null || b == null || b == 0.0) "-" else String.format(L, "%+.0f%%", (a - b) / b * 100)

    private fun stats(r: List<Reading>) = String.format(
        L, "n=%-2d ↓%6s ↑%6s %4sms %4s", r.size,
        f(avg(r.map { it.down })), f(avg(r.map { it.up })), f(avg(r.map { it.ping }), 0),
        f(avg(r.map { it.dbm?.toDouble() }), 0)
    )

    fun build(all: List<Reading>, filter: String, here: Location?): String {
        val sb = StringBuilder()
        fun head(t: String) { sb.append("\n━━ ").append(t).append(" ━━\n") }
        val data = all.filter { filter == "All" || it.net == filter }
        val tests = data.filter { it.kind == "speed" && it.down != null }
        val dt = SimpleDateFormat("MM-dd HH:mm", L)
        val day = SimpleDateFormat("yyyy-MM-dd", L)

        head("HISTORY  (filter: $filter)")
        sb.append("  ${all.size} saved, ${all.count { it.kind == "speed" }} speed tests\n")
        if (data.isEmpty()) { sb.append("  No data yet. Tap [Speed test].\n"); return sb.toString() }
        sb.append("  ↓ down Mbps  ↑ up Mbps  ping  dBm\n")
        data.take(8).forEach { r ->
            if (r.kind == "speed") sb.append(String.format(L, "  %s %-6s ↓%5s ↑%5s %3sms\n", dt.format(Date(r.ts)), r.net, f(r.down), f(r.up), f(r.ping, 0)))
            else sb.append(String.format(L, "  %s %-6s snapshot %s dBm\n", dt.format(Date(r.ts)), r.net, r.dbm ?: "-"))
            sb.append("      ").append(r.place.take(34)).append('\n')
        }

        if (tests.size >= 2) {
            val a = tests[0]; val b = tests[1]
            head("LATEST vs PREVIOUS")
            sb.append("  Download : ${f(a.down)} vs ${f(b.down)}  (${pct(a.down, b.down)})\n")
            sb.append("  Upload   : ${f(a.up)} vs ${f(b.up)}  (${pct(a.up, b.up)})\n")
            sb.append("  Ping     : ${f(a.ping, 0)} vs ${f(b.ping, 0)} ms\n")
            if (a.net != b.net) sb.append("  note: different networks (${a.net} / ${b.net})\n")
        }

        head("COMPARE BY TIME OF DAY")
        val byPart = partOrder.associateWith { p -> data.filter { part(it.ts) == p } }.filter { it.value.isNotEmpty() }
        val bestPart = byPart.filter { avg(it.value.map { r -> r.down }) != null }
            .maxByOrNull { avg(it.value.map { r -> r.down }) ?: 0.0 }?.key
        byPart.forEach { (p, rows) ->
            sb.append(if (p == bestPart && byPart.size > 1) "★ " else "  ").append(String.format(L, "%-9s", p)).append(stats(rows)).append('\n')
        }

        head("COMPARE BY DAY (last 7)")
        data.groupBy { day.format(Date(it.ts)) }.entries.take(7).forEach { (d, rows) ->
            sb.append("  ").append(d.substring(5)).append("  ").append(stats(rows)).append('\n')
        }

        head("COMPARE BY LOCATION")
        val byLoc = data.filter { it.lat != null && it.lon != null }.groupBy { key(it.lat!!, it.lon!!) }
        if (byLoc.isEmpty()) sb.append("  No location saved yet (grant location).\n") else {
            val sorted = byLoc.entries.sortedByDescending { avg(it.value.map { r -> r.down }) ?: -1.0 }
            val scored = sorted.filter { avg(it.value.map { r -> r.down }) != null }
            sorted.take(6).forEach { e ->
                val mark = when {
                    scored.size > 1 && e == scored.first() -> "★ best  "
                    scored.size > 1 && e == scored.last() -> "▼ worst "
                    else -> "        "
                }
                sb.append("  ").append(mark).append(e.value.first().place.take(26)).append('\n')
                sb.append("     ").append(stats(e.value)).append('\n')
            }
        }

        if (here != null) {
            head("THIS LOCATION")
            val k = key(here.latitude, here.longitude)
            val hereRows = data.filter { it.lat != null && it.lon != null && key(it.lat, it.lon) == k }
            if (hereRows.isEmpty()) sb.append("  No readings here yet.\n") else {
                sb.append("  Here      ").append(stats(hereRows)).append('\n')
                sb.append("  All places").append(stats(data)).append('\n')
                sb.append("  Download here vs overall: ")
                    .append(pct(avg(hereRows.map { it.down }), avg(data.map { it.down }))).append('\n')
                partOrder.forEach { p ->
                    val rows = hereRows.filter { part(it.ts) == p }
                    if (rows.isNotEmpty()) sb.append("  ").append(String.format(L, "%-10s", p)).append(stats(rows)).append('\n')
                }
            }
        }
        return sb.toString()
    }
}

package com.example.phonediag

import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicLong

data class SpeedResult(val pingMs: Double, val jitterMs: Double, val downMbps: Double, val upMbps: Double)

/**
 * Simple multi-thread HTTP speed test against Cloudflare's public speed endpoints.
 * Change DOWN / UP below to use your own server if you prefer.
 */
object SpeedTest {
    private const val DOWN = "https://speed.cloudflare.com/__down?bytes="
    private const val UP = "https://speed.cloudflare.com/__up"
    private const val DOWN_SECONDS = 8
    private const val UP_SECONDS = 6
    private const val THREADS = 4

    /** Live values for the gauge. */
    @Volatile var liveMbps = 0.0
    @Volatile var phase = ""

    private fun open(url: String, post: Boolean = false): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000
            readTimeout = 8000
            useCaches = false
            setRequestProperty("User-Agent", "PhoneDiagnostics/1.0")
            if (post) { requestMethod = "POST"; doOutput = true }
        }

    fun run(progress: (String) -> Unit): SpeedResult {
        phase = "Ping"; liveMbps = 0.0
        progress("Testing latency...")
        val ping = latency()
        val down = download(progress)
        val up = upload(progress)
        return SpeedResult(ping.first, ping.second, down, up)
    }

    private fun latency(): Pair<Double, Double> {
        val t = ArrayList<Double>()
        repeat(7) { i ->
            val t0 = System.nanoTime()
            val c = open(DOWN + "0")
            c.responseCode
            c.inputStream.use { it.readBytes() }
            c.disconnect()
            if (i > 0) t += (System.nanoTime() - t0) / 1e6 // skip first (TLS handshake)
        }
        val avg = t.average()
        val jitter = t.zipWithNext { a, b -> Math.abs(a - b) }.average()
        return avg to jitter
    }

    private fun download(progress: (String) -> Unit): Double {
        val total = AtomicLong()
        val start = System.nanoTime()
        val end = start + DOWN_SECONDS * 1_000_000_000L
        val workers = (1..THREADS).map {
            Thread {
                val buf = ByteArray(65536)
                try {
                    while (System.nanoTime() < end) {
                        val c = open(DOWN + "25000000")
                        c.inputStream.use { ins ->
                            while (System.nanoTime() < end) {
                                val n = ins.read(buf)
                                if (n < 0) break
                                total.addAndGet(n.toLong())
                            }
                        }
                        c.disconnect()
                    }
                } catch (_: Exception) {}
            }.also { it.start() }
        }
        while (workers.any { it.isAlive }) {
            Thread.sleep(500)
            val s = (System.nanoTime() - start) / 1e9
            liveMbps = total.get() * 8 / s / 1e6; phase = "Download"
            progress("Download: %.1f Mbps".format(liveMbps))
        }
        val s = (System.nanoTime() - start) / 1e9
        return total.get() * 8 / s / 1e6
    }

    private fun upload(progress: (String) -> Unit): Double {
        val total = AtomicLong()
        val start = System.nanoTime()
        val end = start + UP_SECONDS * 1_000_000_000L
        val chunk = ByteArray(65536)
        val workers = (1..3).map {
            Thread {
                try {
                    while (System.nanoTime() < end) {
                        val size = 2_000_000
                        val c = open(UP, post = true)
                        c.setFixedLengthStreamingMode(size)
                        c.outputStream.use { os ->
                            var sent = 0
                            while (sent < size && System.nanoTime() < end + 1_000_000_000L) {
                                val n = minOf(chunk.size, size - sent)
                                os.write(chunk, 0, n)
                                sent += n
                                total.addAndGet(n.toLong())
                            }
                        }
                        c.responseCode
                        c.disconnect()
                    }
                } catch (_: Exception) {}
            }.also { it.start() }
        }
        while (workers.any { it.isAlive }) {
            Thread.sleep(500)
            val s = (System.nanoTime() - start) / 1e9
            liveMbps = total.get() * 8 / s / 1e6; phase = "Upload"
            progress("Upload: %.1f Mbps".format(liveMbps))
        }
        val s = (System.nanoTime() - start) / 1e9
        return total.get() * 8 / s / 1e6
    }
}

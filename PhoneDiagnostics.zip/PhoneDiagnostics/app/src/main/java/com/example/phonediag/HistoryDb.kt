package com.example.phonediag

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Reading(
    val ts: Long,
    val lat: Double?,
    val lon: Double?,
    val place: String,
    val net: String,        // "Wi-Fi", "Mobile", "None"
    val carrier: String,    // SSID or operator + tech
    val dbm: Int?,
    val down: Double?,
    val up: Double?,
    val ping: Double?,
    val jitter: Double?,
    val battery: Int,
    val kind: String        // "speed" or "snap"
)

class HistoryDb(ctx: Context) : SQLiteOpenHelper(ctx, "history.db", null, 1) {

    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL(
            "CREATE TABLE readings(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, lat REAL, lon REAL, " +
                "place TEXT, net TEXT, carrier TEXT, dbm INTEGER, down REAL, up REAL, ping REAL, jitter REAL, " +
                "battery INTEGER, kind TEXT)"
        )
    }

    override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {}

    @Synchronized
    fun insert(r: Reading) {
        val v = ContentValues()
        v.put("ts", r.ts)
        v.put("lat", r.lat)
        v.put("lon", r.lon)
        v.put("place", r.place)
        v.put("net", r.net)
        v.put("carrier", r.carrier)
        v.put("dbm", r.dbm)
        v.put("down", r.down)
        v.put("up", r.up)
        v.put("ping", r.ping)
        v.put("jitter", r.jitter)
        v.put("battery", r.battery)
        v.put("kind", r.kind)
        writableDatabase.insert("readings", null, v)
    }

    @Synchronized
    fun all(): List<Reading> {
        val out = ArrayList<Reading>()
        readableDatabase.rawQuery(
            "SELECT ts,lat,lon,place,net,carrier,dbm,down,up,ping,jitter,battery,kind FROM readings ORDER BY ts DESC", null
        ).use { c ->
            fun d(i: Int): Double? = if (c.isNull(i)) null else c.getDouble(i)
            while (c.moveToNext()) {
                out += Reading(
                    c.getLong(0), d(1), d(2), c.getString(3) ?: "", c.getString(4) ?: "", c.getString(5) ?: "",
                    if (c.isNull(6)) null else c.getInt(6), d(7), d(8), d(9), d(10), c.getInt(11), c.getString(12) ?: ""
                )
            }
        }
        return out
    }

    @Synchronized
    fun clear() { writableDatabase.delete("readings", null, null) }

    fun csv(): String {
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
        val sb = StringBuilder("time,lat,lon,place,network,carrier,signal_dbm,down_mbps,up_mbps,ping_ms,jitter_ms,battery,kind\n")
        for (r in all().reversed()) {
            sb.append(fmt.format(Date(r.ts))).append(',')
                .append(r.lat ?: "").append(',').append(r.lon ?: "").append(',')
                .append(q(r.place)).append(',').append(r.net).append(',').append(q(r.carrier)).append(',')
                .append(r.dbm ?: "").append(',').append(r.down ?: "").append(',').append(r.up ?: "").append(',')
                .append(r.ping ?: "").append(',').append(r.jitter ?: "").append(',')
                .append(r.battery).append(',').append(r.kind).append('\n')
        }
        return sb.toString()
    }
}
